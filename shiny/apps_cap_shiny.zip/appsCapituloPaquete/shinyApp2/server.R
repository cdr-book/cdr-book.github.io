source("../shinyApp/source.R")
shinyServer(function(input, output) {
  output$gra1 <- renderPlot({
    graf_evol(input$vble)
  })  
  
  output$gra2 <- renderPlot({
    graf_evol("tramo_edad")
  })  
  output$gra3 <- renderPlot({
    graf_evol("tiempo_búsqueda_empleo")
  })  
})
