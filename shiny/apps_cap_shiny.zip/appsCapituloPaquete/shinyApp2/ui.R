shinyUI(fluidPage(
  headerPanel("Evolución del paro"), # panel de encabezado
  mainPanel(
#    plotOutput("gra1")
      tabsetPanel(
        tabPanel("Elección con botones circulares", 
                 radioButtons("vble", "Variable", # botones circulares: nombre y etiqueta
                              c("sexo" = "sexo",
                                "tramo_edad" = "tramo_edad",
                                "tiempo_búsqueda_empleo_agregado" = "tiempo_búsqueda_empleo_agregado",
                                "sector" = "sector",
                                "tiempo_búsqueda_empleo" = "tiempo_búsqueda_empleo"), "sexo")
        ,plotOutput("gra1")), 
        tabPanel("Tramo edad fijo",  plotOutput("gra2")), 
        tabPanel("Tiempo búsqueda empleo fijo",  plotOutput("gra3"))
      )
  )
))
