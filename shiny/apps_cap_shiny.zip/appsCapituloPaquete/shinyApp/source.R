library("CDR")
# ------------------------------------------------------------------------------------?
# (c) Observatorio del Mercado de Trabajo. Junta de Comunidades de Castilla-La Mancha ?
# (c) Isidro Hidalgo Arellano (ihidalgo@jccm.es)                                      ?
# ------------------------------------------------------------------------------------?

# Borramos los objetos en memoria
rm(list = ls(all.names = TRUE))

# Cargamos las librer?as necesarias
library(openxlsx)
library(tidyverse)
library(ggpubr)


# Establecemos variables y par?metros generales...
options(warn=-1)
# paleta_heatmaps <- c(rgb(.8,.9,.8,1), rgb(.753,0,0,1))
# paleta_heatmaps <- c(rgb(.77,.89,.64,1),  rgb(.13,.22,.58,1))
paleta_heatmaps <- c(rgb(.7,1,0,.5),  rgb(.13,.22,.58,1))

paleta_lineas <- c("blue4", "orange","darkgreen", "red", "black", "pink",
                   "lightblue", "darkorange","lightgreen", "red4", "azure4", "green")
tipo_lineas <- c("dashed", "solid", "longdash", "dotdash", "dotted", "solid",
                 "solid", "solid", "longdash", "solid", "dotdash", "solid", "dotdash")

variables <- tibble(var = c("edad",
                            "sexo",
                            "tramo_edad",
                            "tiempo_busqueda_empleo_agregado",
                            "sector",
                            "tiempo_busqueda_empleo"),
                    literal = c("edad",
                                "sexo",
                                "tramo de edad",
                                "tiempo de busqueda de empleo agregado",
                                "sector",
                                "tiempo de busqueda de empleo")
) # variables



graf_evol <- function(variable){
  # INPUT: variable [alfanum?rico; nombre de la variable a representar]
  # Produce 2 gr?ficos de evoluci?n de la variable respecto al tiempo (desde 2007 hasta 2022):
  # - El primer gr?fico (izquierda) muestra la evoluci?n del paro registrado en valor absoluto
  # - El segundo gr?fico (derecha) muestra la evoluci?n de la distribuci?n del paro registrado
  #   en porcentaje
  tabla <- select(parados_clm, anyo, variable, parados)
  names(tabla) <- c("año", "variable", "parados")
  
  tabla_absolutos <- tabla %>%
    group_by(año, variable) %>% 
    summarise(parados = sum(parados))
  
  graf_absolutos <- ggplot(tabla_absolutos, aes(x = año, y = parados)) +
    geom_line(aes(group = variable, color = variable, linetype = variable),
              size = 1.2, alpha = 0.6) +
    scale_color_manual(values = paleta_lineas, name = NULL) +
    scale_linetype_manual(values = tipo_lineas, name = NULL) +
    expand_limits(y = 0) +
    theme(legend.position = "none", axis.text = element_text(face="bold")) +
    xlab("") +
    ylab("número de parados") +
    guides(linetype = "none") +
    scale_y_continuous(labels = function(x) format(x, big.mark = ".", scientific = FALSE))
  
  tabla_porcentajes <- tabla %>%
    group_by(año) %>% 
    mutate(totales = sum(parados)) %>%
    group_by(variable, .add = TRUE) %>%
    summarise(porcentaje = 100*parados/totales) %>%
    group_by(año, variable) %>%
    summarise(porcentaje = sum(porcentaje))
  
  graf_porcentajes <- ggplot(tabla_porcentajes, aes(x = año, y = porcentaje)) +
    geom_line(aes(group = variable, colour = variable, linetype = variable),
              size = 1.2, alpha = 0.6) +
    scale_color_manual(values = paleta_lineas, name = NULL) +
    scale_linetype_manual(values = tipo_lineas, name = NULL) +
    expand_limits(y = 0) +
    theme(legend.position = "bottom", axis.text = element_text(face="bold")) +
    xlab("") +
    ylab("porcentaje") +
    scale_y_continuous(labels = function(x) format(x, big.mark = ".", scientific = FALSE))
  
  graf <- ggarrange(graf_absolutos,
                    graf_porcentajes,
                    # labels = c("   valores absolutos", "distribuci?n porcentual"),
                    # font.label = list(size = 1, alpha = 0.7),
                    ncol = 1, align = "hv")
  titulo <- paste0("Evolución del paro registrado según ",
                   variables$literal[variables$var == variable])
  graf <- annotate_figure(graf, top = text_grob(titulo, color = "black", face = "bold", size = 10))
  
  return(graf)
  
} # graf_evol