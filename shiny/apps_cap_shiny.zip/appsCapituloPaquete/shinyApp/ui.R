shinyUI(fluidPage(
  headerPanel("Evolución del paro"), # panel de encabezado
  sidebarLayout( 
  sidebarPanel( # panel lateral
    radioButtons("vble", "Variable", # botones circulares: nombre y etiqueta
                 c("sexo" = "sexo",
                   "tramo_edad" = "tramo_edad",
                   "tiempo_búsqueda_empleo_agregado" = "tiempo_búsqueda_empleo_agregado",
                   "sector" = "sector",
                   "tiempo_búsqueda_empleo" = "tiempo_búsqueda_empleo"), "sexo")
  ),
  mainPanel(
    plotOutput("gra1")
  )
)))
