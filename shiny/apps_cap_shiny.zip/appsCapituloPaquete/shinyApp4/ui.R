shinyUI(fluidPage(
  headerPanel("Lectura de datos"),
  sidebarPanel(
    h4("Cargar fichero CSV"),
    fileInput('file1', '',
              accept=c('text/csv', 'text/comma-separated-values,text/plain', '.csv')),
    checkboxInput('header', 'Header (el csv tiene nombres de variables)', TRUE),
    radioButtons('dec', 'Separador de decimales:',
                 c('Punto'=',',
                   'Coma'='.'))
  ),  
  mainPanel(
    tabsetPanel(
      tabPanel("CSV",
               h4("Vista del fichero CSV"), 
               tableOutput('contents')
      )))))