library("shiny")
shinyUI(fluidPage(
  headerPanel("Elementos para la introducción de datos"),
  sidebarLayout(
                sidebarPanel(
                  radioButtons("vble", "Variable",
                               c("sexo" = "sexo",
                                 "tramo_edad" = "tramo_edad",
                                 "tiempo_búsqueda_empleo_agregado" = "tiempo_búsqueda_empleo_agregado",
                                 "sector" = "sector",
                                 "tiempo_búsqueda_empleo" = "tiempo_búsqueda_empleo"), "sexo"),
                  numericInput("obs", "Numero de observaciones:", 10),
                  helpText("aclaraciones"),
                  checkboxGroupInput("fecha2", "Año:",
                                     c("2007" = "2007",
                                       "2013" = "2013",
                                       "2019" = "2019",
                                       "2022" = "2022")),
                  selectInput("fecha", "Año:",
                              c("2007" = "2007",
                                "2013" = "2013",
                                "2019" = "2019",
                                "2022" = "2022"),multiple=TRUE)
                ),
                mainPanel(
                  sliderInput("enteros", "Enteros:", min=0, max=1000, value=500),
                  sliderInput("decimales", "Decimales:",min = 0, max = 1, value = 0.5, step= 0.1),
                  sliderInput("rango", "Rango:",min = 1, max = 1000, value = c(200,500)),
                  sliderInput("animacion", "Animacion:", 10, 200, 10, step = 10, animate=animationOptions(loop=T))
                )
  )))
