shinyUI(fluidPage(
  headerPanel("Evolución del paro"), # panel de encabezado
  sidebarLayout( 
  sidebarPanel( # panel lateral
    radioButtons("vble", "Variable", # botones circulares: nombre y etiqueta
                 c("sexo" = "sexo",
                   "tramo_edad" = "tramo_edad",
                   "tiempo_búsqueda_empleo_agregado" = "t_bus_e_agr",
                   "sector" = "sector",
                   "tiempo_búsqueda_empleo" = "t_bus_e"), "sexo")
  ),
  mainPanel(
    plotOutput("gra1")
  )
)))
