shinyUI(fluidPage(
  headerPanel("Controlar reactividad"),
  sidebarPanel(
    radioButtons("dist", "Tipo de distribucion:",
                 c("Normal" = "norm",
                   "Uniforme" = "unif",
                   "Log-normal" = "lnorm",
                   "Exponencial" = "exp"), selected= "Exponencial"),
    numericInput("obs", "Numero de observaciones:", 10),
  ),  
  mainPanel( 
    tabPanel('Histograma distribucion RadioButton', 
             'Plot', plotOutput("plot"), actionButton("botonReac", "Presiona")
    )
  )
  
))