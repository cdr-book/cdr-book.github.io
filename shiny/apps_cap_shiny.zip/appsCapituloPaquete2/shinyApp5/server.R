library("RColorBrewer")
mypalette<-brewer.pal(11,"Accent")
shinyServer(function(input, output) {
  datos <- reactive({  
    if(input$botonReac == 0) return (dist(rexp(input$obs)))
    isolate({
      dist <- switch(input$dist,
                     norm = rnorm,
                     unif = runif,
                     lnorm = rlnorm,
                     exp = rexp,
                     rnorm)
      
      dist(input$obs) 
    })
  })
  
  output$plot <- renderPlot({
    if(input$botonReac == 0) return (NULL)
    isolate({
      hist(datos(), col=mypalette,
           main=paste('r', input$dist, '(', input$obs, ')', sep=''))
    })
  })
})